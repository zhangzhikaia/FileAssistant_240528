﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.
#include "FFAItem.h"

#include "FAUtilities.h"

FFAItem::FFAItem(FString InShortcutPath)
{
	ShortcutPath = InShortcutPath;
}

FString FFAItem::GetShortcutPath()
{
	return ShortcutPath;
}

FString FFAItem::GetDirectoryPath()
{
	return FPaths::GetPath(FAUtilities::GetShortcutTargetPath(*ShortcutPath));
}

FString FFAItem::GetBaseName()
{
	return FPaths::GetBaseFilename(ShortcutPath);
}

FName FFAItem::GetIconName()
{
	return FName(FString("IconSet.") + GetBaseName());
}

FString FFAItem::GetIconPath()
{
	return FPaths::Combine(FAUtilities::GetIconsDirectory(),GetBaseName() + ".png");
}

FSimpleDelegate& FFAItem::OnRenameRequested()
{
	return RenameRequestedEvent;
}

FSimpleDelegate& FFAItem::OnRenameCanceled()
{
	return RenameCanceledEvent;
}
