﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once

class ISlateStyle;

class FIconStyle
{
public:

	static void InitializeIcons(); //这个函数是自定义的，实际的初始化需被整个模块的初始化构造调用

	static void ShutDownIcons();

	static void RefreshSet();

	static const ISlateStyle& Get();

	static FName GetStyleSetName();

private:
	
	static TSharedRef<FSlateStyleSet> CreateSlateStyleSet();
	
	static TSharedPtr<FSlateStyleSet> CreatedSlateStyleSet;
};


class FToolBarIconStyle
{
public:

	static void Initialize(); //这个函数是自定义的，实际的初始化需被整个模块的初始化构造调用

	static void ShutDown();

	static void ReloadTextures();

	static const ISlateStyle& Get();

	static FName GetToolBarStyleSetName();

private:
	
	static TSharedRef<FSlateStyleSet> CreateToolBarIconStyle();
	
	static TSharedPtr<FSlateStyleSet> CreatedToolBarIconStyle;
};